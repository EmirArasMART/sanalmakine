#!/usr/bin/env python3
"""Shrink links2 built-in fonts: keep only Latin (incl. Turkish), Greek, Cyrillic, common punctuation."""
import re, sys
src = open(sys.argv[1], encoding='latin-1').read()
KEEP = [(0x0, 0x24F), (0x370, 0x3FF), (0x400, 0x45F), (0x2000, 0x206F), (0x20A0, 0x20BF),
        (0x2100, 0x2122), (0x2190, 0x2193), (0x2500, 0x257F), (0x25A0, 0x25CF), (0xFB01, 0xFB02), (0xFFFD, 0xFFFD)]
keep = lambda cp: any(a <= cp <= b for a, b in KEEP)
m = re.search(r'struct letter letter_data\[(\d+)\] = \{\n(.*?)\n\};', src, re.S)
entries = re.findall(r'\{ (letter_\d+), (0x[0-9a-f]+), (0x[0-9a-f]+),\s*(\d+),\s*(\d+), NULL \}', m.group(2))
ft = re.search(r'struct font font_table\[(\d+)\] = \{\n(.*?)\n\};', src, re.S)
fonts = [tuple(map(int, x)) for x in re.findall(r'\{ (\d+), (\d+) \}', ft.group(2))]
new_entries, new_fonts, used = [], [], set()
for start, cnt in fonts:
    s = len(new_entries)
    for e in entries[start:start + cnt]:
        if keep(int(e[2], 16)) or cnt == 1:
            new_entries.append(e); used.add(e[0])
    new_fonts.append((s, len(new_entries) - s))
# drop unused letter arrays
def repl(mm):
    return mm.group(0) if mm.group(1) in used else ''
body = re.sub(r'static_const unsigned char (letter_\d+)\[\] = ".*?";\n', repl, src, flags=re.S)
body = re.sub(r'struct letter letter_data\[\d+\] = \{\n.*?\n\};',
              'struct letter letter_data[%d] = {\n%s\n};' % (len(new_entries), '\n'.join(
                  '\t{ %s, %s, %s, %s, %s, NULL },' % e for e in new_entries)), body, flags=re.S)
body = re.sub(r'struct font font_table\[\d+\] = \{\n.*?\n\};',
              'struct font font_table[%d] = {\n%s\n};' % (len(new_fonts), '\n'.join(
                  '\t{ %d, %d },' % f for f in new_fonts)), body, flags=re.S)
open(sys.argv[2], 'w', encoding='latin-1').write(body)
print('letters', len(entries), '->', len(new_entries), 'fonts', fonts, '->', new_fonts)
