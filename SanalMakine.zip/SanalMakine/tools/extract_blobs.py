#!/usr/bin/env python3
"""index.html icine gomulu dosyalari (cekirdek, initrd, BIOS) geri cikarir.
Boylece Linux'u yeniden derlemeden build_web.py tekrar calistirilabilir.
Kullanim: python3 tools/extract_blobs.py index.html"""
import base64, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
html = open(sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "index.html"), encoding="utf-8").read()
targets = {"bzimage": "guest/build/bzImage", "initrd": "guest/build/initrd.xz",
           "seabios": "guest/bios/seabios.bin", "vgabios": "guest/bios/vgabios.bin"}
for name, rel in targets.items():
    m = re.search(r'<script type="application/octet-stream" id="blob-%s">(.*?)</script>' % name, html, re.S)
    if not m: sys.exit("bulunamadi: " + name)
    out = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(out), exist_ok=True)
    data = base64.b64decode(re.sub(r"\s+", "", m.group(1)))
    open(out, "wb").write(data); print(rel, len(data), "bayt")
