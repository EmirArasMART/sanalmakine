#!/usr/bin/env python3
"""Tek dosyalik sanal-makine.html olusturur.

Girdi dosyalari (varsayilan yollar ortam degiskenleriyle degistirilebilir):
  V86_JS      v86 libv86.js (npm paketi v86)
  V86_WASM    v86-fallback.wasm (SIMD'siz surum)
  SEABIOS     seabios.bin, VGABIOS vgabios.bin (github.com/copy/v86/bios)
  BZIMAGE     guest/build/bzImage, INITRD guest/build/initrd.xz
Araclar: npx binaryen (wasm-opt) ve esbuild  ->  `npm install` (tools/package.json)
"""
import base64, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BIN = os.path.join(HERE, "node_modules", ".bin")
env = lambda k, d: os.environ.get(k, d)

V86_JS = env("V86_JS", os.path.join(HERE, "node_modules/v86/build/libv86.js"))
V86_WASM = env("V86_WASM", os.path.join(HERE, "node_modules/v86/build/v86-fallback.wasm"))
SEABIOS = env("SEABIOS", os.path.join(ROOT, "guest/bios/seabios.bin"))
VGABIOS = env("VGABIOS", os.path.join(ROOT, "guest/bios/vgabios.bin"))
BZIMAGE = env("BZIMAGE", os.path.join(ROOT, "guest/build/bzImage"))
INITRD = env("INITRD", os.path.join(ROOT, "guest/build/initrd.xz"))
OUT = env("OUT", os.path.join(ROOT, "dist/web/sanal-makine.html"))
TMP = os.path.join(ROOT, "dist/.tmp")
os.makedirs(TMP, exist_ok=True)
os.makedirs(os.path.dirname(OUT), exist_ok=True)

# 1) WASM'i MVP seviyesine indir (Firefox 52 / eski WebView icin: bulk-memory, sign-ext, sat-conv yok)
wasm_out = os.path.join(TMP, "v86.mvp.wasm")
subprocess.check_call([os.path.join(BIN, "wasm-opt"), V86_WASM,
    "--enable-bulk-memory", "--enable-reference-types", "--enable-mutable-globals",
    "--enable-sign-ext", "--enable-nontrapping-float-to-int", "--enable-multivalue",
    "--llvm-memory-copy-fill-lowering", "--signext-lowering", "--llvm-nontrapping-fptoint-lowering",
    "-O1", "-o", wasm_out])
subprocess.check_call([os.path.join(BIN, "wasm-opt"), wasm_out, "--mvp-features", "-o", wasm_out])  # dogrulama

# 2) libv86.js: video modu yamasi + ES2017'ye indirme
js = open(V86_JS, encoding="utf-8").read()
js, n = re.subn(r"(\w)\[253\]=65535;", r'\1[253]=(typeof V86_VIDMODE!="undefined"?V86_VIDMODE:65535);', js)
assert n == 1, "vid_mode yamasi uygulanamadi (v86 surumu degismis olabilir)"
patched = os.path.join(TMP, "libv86.patched.js")
open(patched, "w", encoding="utf-8").write(js)
lowered = os.path.join(TMP, "libv86.es2017.js")
subprocess.check_call([os.path.join(BIN, "esbuild"), patched, "--target=es2017",
    "--minify-whitespace", "--minify-syntax", "--log-level=warning", "--outfile=" + lowered])
js = open(lowered, encoding="utf-8").read()
js = re.sub(r"([^A-Za-z0-9_$.])import\(", r"\1__v86imp(", js)          # dinamik import (sadece Node yolu)
js = js.replace("globalThis", '(typeof globalThis!=="undefined"?globalThis:self)')  # worker icinde de calissin
js = "function __v86imp(m){return Promise.reject(new Error('import'))}\n" + js
js = js.replace("</script", "<\\/script")

# 3) HTML'i birlestir
tpl = open(os.path.join(ROOT, "web/template.html"), encoding="utf-8").read()
def blob(name, path):
    data = base64.b64encode(open(path, "rb").read()).decode()
    lines = "\n".join(data[i:i + 4096] for i in range(0, len(data), 4096))
    return '<script type="application/octet-stream" id="blob-%s">\n%s\n</script>\n' % (name, lines)
blobs = (blob("wasm", wasm_out) + blob("seabios", SEABIOS) + blob("vgabios", VGABIOS) +
         blob("bzimage", BZIMAGE) + blob("initrd", INITRD))
html = tpl.replace("<!--DATA-->", blobs).replace("/*LIBV86*/", js)
open(OUT, "w", encoding="utf-8").write(html)
print("yazildi:", OUT, "%.1f MB" % (len(html) / 1048576))
