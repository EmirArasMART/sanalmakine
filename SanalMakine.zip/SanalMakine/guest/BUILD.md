# Mini Linux'u sıfırdan derleme

Ubuntu 24.04 (x86_64) üzerinde test edildi. Hepsi 32-bit (i386) statik olarak derlenir.

## 0) Paketler

```sh
sudo dpkg --add-architecture i386 && sudo apt update
sudo apt install build-essential gcc-multilib bc flex bison libelf-dev cpio xz-utils autoconf automake libtool \
  libssl-dev:i386 zlib1g-dev:i386 libpng-dev:i386 libjpeg-turbo8-dev:i386 libgpm-dev:i386
```

## 1) Çekirdek (Linux 6.6)

```sh
git clone --depth 1 --branch v6.6 https://github.com/torvalds/linux.git && cd linux
cp ../guest/kernel.config .config
make ARCH=i386 olddefconfig && make ARCH=i386 -j$(nproc) bzImage
cp arch/x86/boot/bzImage ../guest/build/bzImage
```

`kernel.config` tinyconfig tabanlıdır: VESA framebuffer, PS/2 klavye/fare, NE2000 + virtio-net, ATA/CD-ROM,
ISO9660/ext2/FAT, xz initramfs ve `COMPAT_32BIT_TIME` (glibc için gerekli) açıktır.
Grafik mod için v86'nın kernel yükleyicisi `vid_mode` alanını 0x314 (800x600x16) yapacak şekilde yamalanır
(`tools/build_web.py` içinde, `V86_VIDMODE` değişkeni).

## 2) BusyBox

Ubuntu'nun i386 statik paketi kullanıldı:

```sh
apt-get download busybox-static:i386 && dpkg-deb -x busybox-static_*_i386.deb bb
cp bb/usr/bin/busybox guest/build/bin/busybox
```

## 3) Küçük OpenSSL (Links için)

```sh
# openssl_3.0.13.orig.tar.gz  (archive.ubuntu.com/ubuntu/pool/main/o/openssl/)
./Configure linux-x86 -m32 -Os --prefix=$PWD/../ossl no-shared no-tests no-engine no-legacy no-dso no-comp \
  no-dtls no-srp no-psk no-cms no-ts no-ct no-sm2 no-sm3 no-sm4 no-idea no-camellia no-seed no-aria no-bf \
  no-cast no-des no-rc2 no-rc4 no-md4 no-mdc2 no-rmd160 no-whirlpool no-siphash no-scrypt no-ssl3 no-tls1 \
  no-tls1_1 no-ui-console no-gost no-afalgeng no-padlockeng no-devcryptoeng no-ec2m no-dsa no-cmac no-srtp \
  no-sctp no-nextprotoneg no-async no-blake2 no-ocb no-rfc3779 no-autoload-config no-err no-filenames \
  no-module no-threads no-ssl-trace no-unit-test no-uplink no-weak-ssl-ciphers
make -j$(nproc) build_libs && make install_dev
```

## 4) gpm (fare sunucusu)

```sh
# gpm_1.20.7.orig.tar.gz + gpm_1.20.7-11.debian.tar.xz  (archive.ubuntu.com/ubuntu/pool/main/g/gpm/)
tar xzf gpm_1.20.7.orig.tar.gz && cd gpm-1.20.7 && tar xJf ../gpm_1.20.7-11.debian.tar.xz
for p in $(grep -v '^#' debian/patches/series); do patch -p1 < debian/patches/$p; done
./autogen.sh
CC="gcc -m32" CFLAGS="-Os -m32 -fcommon" LDFLAGS="-m32 -static" ./configure --host=i686-linux-gnu --without-curses --disable-shared
make -C src gpm && strip -o ../guest/build/bin/gpm src/gpm
```

## 5) Links 2.29 (grafik framebuffer + metin)

```sh
# links2_2.29.orig.tar.bz2  (archive.ubuntu.com/ubuntu/pool/universe/l/links2/)
tar xjf links2_2.29.orig.tar.bz2 && cd links-2.29
python3 ../tools/prune_links_fonts.py font_inc.c font_inc.c.new && mv font_inc.c.new font_inc.c   # yazı tiplerini küçült
CC="gcc -m32" CFLAGS="-Os -m32 -ffunction-sections -fdata-sections" LDFLAGS="-m32 -static -Wl,--gc-sections" \
PKG_CONFIG_PATH=/usr/lib/i386-linux-gnu/pkgconfig ./configure --host=i686-linux-gnu \
  --enable-graphics --with-fb --without-x --without-directfb --without-svgalib --without-openmp --with-gpm \
  --with-ssl=$PWD/../ossl --disable-ssl-pkgconfig --without-libtiff --without-librsvg --without-libwebp \
  --without-libavif --without-bzip2 --without-lzma --without-zstd --without-brotli --without-freetype --without-fontconfig
make -j$(nproc) && strip -o ../guest/build/bin/links links
```

## 6) initramfs ve HTML

```sh
guest/make_initrd.sh          # -> guest/build/initrd.xz
# BIOS: https://github.com/copy/v86/tree/master/bios  -> guest/bios/seabios.bin, vgabios.bin
cd tools && npm install && python3 build_web.py
```
