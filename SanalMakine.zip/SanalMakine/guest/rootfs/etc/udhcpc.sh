#!/bin/sh
case "$1" in
  deconfig) ifconfig $interface 0.0.0.0 ;;
  bound|renew)
    ifconfig $interface $ip ${subnet:+netmask $subnet} ${broadcast:+broadcast $broadcast}
    if [ -n "$router" ]; then while route del default gw 0.0.0.0 dev $interface 2>/dev/null; do :; done
      for r in $router; do route add default gw $r dev $interface; done; fi
    : > /etc/resolv.conf
    for d in $dns; do echo "nameserver $d" >> /etc/resolv.conf; done
    [ -s /etc/resolv.conf ] || echo "nameserver 1.1.1.1" > /etc/resolv.conf ;;
esac
exit 0
