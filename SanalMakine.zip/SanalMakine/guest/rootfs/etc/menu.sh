#!/bin/sh
# Ana menu
export HOME=/root TERM=linux
START=file:///usr/share/sanal/index.html
while true; do
  clear
  printf '\033[1;36m'
  echo "  ____                    _   __  __       _    _"
  echo " / ___|  __ _ _ __   __ _| | |  \/  | __ _| | _(_)_ __   ___"
  echo " \___ \ / _\` | '_ \ / _\` | | | |\/| |/ _\` | |/ / | '_ \ / _ \\"
  echo "  ___) | (_| | | | | (_| | | | |  | | (_| |   <| | | | |  __/"
  echo " |____/ \__,_|_| |_|\__,_|_| |_|  |_|\__,_|_|\_\_|_| |_|\___|"
  printf '\033[0m\n'
  echo "  Mini Linux $(uname -r)  -  acik kaynak (GPL)"
  IP=$(ifconfig eth0 2>/dev/null | sed -n 's/.*inet addr:\([0-9.]*\).*/\1/p')
  [ -n "$IP" ] && echo "  Ag: bagli ($IP)" || echo "  Ag: yok (cevrimdisi)"
  echo
  echo "   1) Grafik tarayici   (Links, fare destekli)"
  echo "   2) Metin tarayici    (Links, klavye ile)"
  echo "   3) Komut satiri      (sh)"
  echo "   4) Sistem bilgisi"
  echo "   5) Yeniden baslat"
  echo
  printf "  Seciminiz [1]: "
  read c
  case "$c" in
    ""|1) pidof gpm >/dev/null || gpm -m /dev/input/mice -t ps2 2>/dev/null
          if [ -e /dev/fb0 ]; then links -g -driver fb -ssl.builtin-certificates 1 -menu-font-size 18 "$START"; else echo "Ekran kartinda grafik mod yok, metin tarayici aciliyor..."; sleep 2; links -ssl.builtin-certificates 1 "$START"; fi ;;
    2) links -ssl.builtin-certificates 1 "$START" ;;
    3) clear; echo "Menuye donmek icin: exit"; sh ;;
    4) clear; uname -a; echo; free; echo; df -h 2>/dev/null; echo; cat /proc/cpuinfo | grep -m1 "model name"; echo; printf "Devam icin Enter..."; read x ;;
    5) reboot -f ;;
  esac
done
