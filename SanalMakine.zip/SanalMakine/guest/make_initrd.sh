#!/bin/sh
# Mini Linux initramfs olusturur: rootfs/ + busybox + links + gpm  ->  build/initrd.xz
# Gerekenler: build/bin/busybox (i386 statik), build/bin/links, build/bin/gpm  (bkz. BUILD.md)
set -e
cd "$(dirname "$0")"
T=$(mktemp -d)
cp -a rootfs/. "$T/"
mkdir -p "$T/bin" "$T/sbin" "$T/usr/bin" "$T/usr/sbin" "$T/proc" "$T/sys" "$T/dev" "$T/tmp" "$T/run" "$T/var"
cp build/bin/busybox "$T/bin/busybox"
cp build/bin/links "$T/usr/bin/links"
cp build/bin/gpm "$T/usr/sbin/gpm"
for a in $("$T/bin/busybox" --list-full); do [ -e "$T/$a" ] || ln -s /bin/busybox "$T/$a"; done
(cd "$T" && find . | sort | cpio -o -H newc --owner root:root 2>/dev/null | xz -9e --check=crc32) > build/initrd.xz
rm -rf "$T"
ls -la build/initrd.xz
