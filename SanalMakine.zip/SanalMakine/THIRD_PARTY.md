# Üçüncü taraf bileşenler

`index.html`, `SanalMakine.apk` ve `SanalMakine.aab` aşağıdaki açık kaynak yazılımların derlenmiş hallerini içerir.
GPL lisanslı bileşenlerin tam kaynak kodu aşağıdaki adreslerde, tam sürüm numaralarıyla bulunur.
Yapılandırma ve yamalar bu repodadır (`guest/kernel.config`, `tools/prune_links_fonts.py`, `guest/BUILD.md`).

| Bileşen | Sürüm | Lisans | Kaynak |
|---|---|---|---|
| v86 (emülatör, libv86.js + v86-fallback.wasm) | 0.5.472 (npm) | BSD-2-Clause | https://github.com/copy/v86 |
| SeaBIOS (seabios.bin) | v86 deposundaki sürüm | LGPL-3.0 | https://www.seabios.org / https://github.com/copy/v86/tree/master/bios |
| VGABIOS (vgabios.bin) | v86 deposundaki sürüm | LGPL-2.1 | https://github.com/copy/v86/tree/master/bios |
| Linux çekirdeği | 6.6 | GPL-2.0 | https://github.com/torvalds/linux/tree/v6.6 |
| BusyBox (Ubuntu busybox-static i386) | 1.36.1-6ubuntu3.1 | GPL-2.0 | http://archive.ubuntu.com/ubuntu/pool/main/b/busybox/ |
| Links (grafik/metin tarayıcı) | 2.29 | GPL-2.0+ | http://archive.ubuntu.com/ubuntu/pool/universe/l/links2/ (links2_2.29.orig.tar.bz2) |
| gpm (konsol fare sunucusu) | 1.20.7 + Debian 1.20.7-11 yamaları | GPL-2.0+ | http://archive.ubuntu.com/ubuntu/pool/main/g/gpm/ |
| OpenSSL | 3.0.13 | Apache-2.0 | http://archive.ubuntu.com/ubuntu/pool/main/o/openssl/ |
| GNU C Library (statik bağlı) | 2.39 (Ubuntu 24.04 i386) | LGPL-2.1+ | http://archive.ubuntu.com/ubuntu/pool/main/g/glibc/ |
| libpng, libjpeg-turbo, zlib (statik bağlı) | Ubuntu 24.04 i386 | libpng / IJG+BSD / zlib | http://archive.ubuntu.com/ubuntu/pool/main/ |

Derleme araçları (pakete dahil değil): binaryen (Apache-2.0), esbuild (MIT), aapt2 ve bundletool (Apache-2.0).

v86 lisansı:

```
Copyright (c) 2012, The v86 contributors
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted
provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions
   and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of
   conditions and the following disclaimer in the documentation and/or other materials provided
   with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```
