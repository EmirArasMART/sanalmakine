# Sanal Makine

Tarayıcıda çalışan açık kaynak bir x86 bilgisayar. Kurulum gerektirmez, tek bir HTML dosyasıdır.
İçinde gömülü bir **Mini Linux** (grafik web tarayıcısıyla) vardır ve internetsiz açılır.
Ayrıca kendi **ISO/IMG** dosyanla Android-x86 ya da 32-bit Linux dağıtımlarını başlatabilirsin.

Motor: [v86](https://github.com/copy/v86) (x86 → WebAssembly JIT emülatörü, BSD-2).

## Dosyalar

| Dosya | Ne işe yarar |
|---|---|
| `index.html` | Sanal makinenin kendisi. Çift tıkla aç ya da GitHub Pages'te yayınla. |
| `SanalMakine.apk` | Android uygulaması (doğrudan kurulum). Android 5.0 ve üstü. |
| `SanalMakine.aab` | Google Play'e yüklemek için Android App Bundle. |
| `web/`, `tools/`, `android/`, `guest/` | Kaynak kodlar ve derleme betikleri |

## Nerelerde çalışır?

Sanallaştırma donanım değil yazılımla yapılır (WebAssembly), bu yüzden işlemcide VT-x/AMD-V gerekmez.
Gereken tek şey **WebAssembly destekleyen bir tarayıcı**:

| Sistem | Tarayıcı |
|---|---|
| Windows XP / Vista | [Supermium](https://github.com/win32ss/supermium) (önerilen) veya Firefox 52 ESR |
| Windows 7 – 11, macOS, Linux | Chrome, Edge, Firefox, Safari (güncel sürümler) |
| Android | Uygulama (APK) ya da Chrome. Güncel "Android System WebView" gerekir. |
| iPhone / iPad | Safari (iOS 11+) |
| ChromeOS | Chrome |

Eski tarayıcılar için WebAssembly modülü MVP seviyesine indirildi ve JavaScript ES2017'ye çevrildi.
Windows XP'deki eski Chrome 49 WebAssembly desteklemediği için çalışmaz; orada Supermium kullan.

## Hangi işletim sistemleri çalışır?

v86, Pentium 4 benzeri **32-bit** bir PC taklit eder. Bu yüzden:

- **Mini Linux (gömülü):** Linux 6.6 + BusyBox + Links. Saniyeler içinde açılır.
  Menüde `1` grafik tarayıcıyı (fare ile), `2` metin tarayıcıyı, `3` komut satırını açar.
- **Android-x86 4.4-r5 (32-bit ISO):** Hazır yüklü Android Browser ile gelir. Açılışı birkaç dakika sürer.
- **Damn Small Linux 4.4.10:** Dillo ve Firefox hazır yüklü gelir, hızlı çalışır.
- **Tiny Core, Alpine x86, Debian i386, antiX 32-bit, Puppy 32-bit, SliTaz** vb. 32-bit dağıtımlar.
- **Çalışmaz:** sadece 64-bit olan sistemler (güncel Ubuntu, Fedora, Android-x86 9+ 64-bit).

Bu ISO'lar 25 MB sınırına sığmadığı için pakette yok. Uygulamadaki listeden resmi indirme sayfasını aç,
dosyayı indir, sonra "ISO / IMG dosyası seç" ile başlat. Dosya hiçbir yere yüklenmez, cihazından okunur.

## İnternet

Başlatmadan önce **Ağ / İnternet** ayarını seç:

- **Tarayıcı (sadece http):** Sunucu gerektirmez. Sadece `http://` siteleri açılır ve sitenin CORS izni vermesi gerekir
  (ör. `http://frogfind.com`, `http://68k.news`). İstersen "CORS proxy" adresi girebilirsin.
- **Relay sunucusu (tam):** `https://` dahil her siteyi açar. Bir WebSocket relay (`wss://...`) ya da
  WISP sunucusu (`wisp://` / `wisps://`) adresi gerekir. Herkese açık ücretsiz sunucular kapanabilir;
  en sağlamı kendi sunucunu kurmaktır (ör. npm'deki `@mercuryworkshop/wisp-js` ya da v86'nın `websockproxy`'si).

## Kullanım ipuçları

- **Bilgisayarda:** Ekrana tıkla, fare sanal makineye kilitlenir. Çıkmak için `Esc`.
- **Tablet/telefonda:** Parmağını kaydırırsan fare hareket eder (touchpad gibi). Dokunursan sol tık, iki parmakla dokunursan sağ tık olur.
  İki parmakla kaydırırsan sayfa kayar. Yazmak için **Klavye** düğmesine bas.
- Üst çubukta Esc, Tab, ok tuşları, Ctrl+C ve Ctrl+Alt+Del düğmeleri var.
- Android'de geri tuşu makineyi kapatıp menüye döner.
- `index.html?os=mini` adresi Mini Linux'u doğrudan açar.

## GitHub Pages ile yayınlama

Repoyu GitHub'a yükle, sonra **Settings → Pages → Branch: main / (root)** seç.
`https://KULLANICI.github.io/REPO/` adresi doğrudan sanal makineyi açar.
Büyük ISO'ları aynı repoya koyarsan (dosya başına en fazla 100 MB) "veya adres (URL)" kutusuna
`https://KULLANICI.github.io/REPO/sistem.iso` yazarak açabilirsin.

## Yeniden derleme

Ayrıntılar `guest/BUILD.md` dosyasında. Kısaca:

```sh
cd tools && npm install                 # v86, binaryen, esbuild
python3 extract_blobs.py ../index.html  # gömülü çekirdeği/initrd'yi çıkar (Linux'u yeniden derlemeden)
python3 build_web.py                    # -> dist/web/sanal-makine.html
cd ../android && ./build_android.sh     # -> dist/android/SanalMakine.apk ve .aab
```

APK ve AAB burada oluşturulmuş bir anahtarla imzalandı. Google Play'e kendi hesabınla yükleyeceksen
`build_android.sh` kendi anahtarını oluşturur (`~/.sanal-makine-release.jks`). Bu anahtarı sakla ve **GitHub'a koyma**.
Farklı anahtarla imzalanmış bir APK'yı güncellemek için eskisini kaldırman gerekir.

## Lisans

Bu projenin kendi kodu MIT lisanslıdır (`LICENSE`). İçindeki açık kaynak bileşenlerin lisansları
ve kaynak kodu adresleri `THIRD_PARTY.md` dosyasında.
