#!/bin/sh
# Sanal Makine Android APK + AAB derleyici (Android Studio / Gradle GEREKMEZ)
#
# Gerekenler (Ubuntu/Debian):
#   sudo apt install openjdk-17-jdk zip zipalign apksigner dalvik-exchange android-sdk-platform-23
#   aapt2      : npm paketi "aaptjs3" (bin/x64/linux/aapt2) veya Android SDK build-tools
#   bundletool : https://github.com/google/bundletool/releases (bundletool-all-*.jar)
# Ortam degiskenleri ile yollar degistirilebilir:
#   AAPT2, ANDROID_JAR, BUNDLETOOL, KEYSTORE, KS_PASS, HTML
set -e
cd "$(dirname "$0")"
AAPT2=${AAPT2:-aapt2}
ANDROID_JAR=${ANDROID_JAR:-/usr/lib/android-sdk/platforms/android-23/android.jar}
BUNDLETOOL=${BUNDLETOOL:-bundletool-all.jar}
KEYSTORE=${KEYSTORE:-$HOME/.sanal-makine-release.jks}
KS_PASS=${KS_PASS:-sanalmakine}
HTML=${HTML:-../dist/web/sanal-makine.html}
VERSION_CODE=${VERSION_CODE:-1}
VERSION_NAME=${VERSION_NAME:-1.0}
OUT=../dist/android
B=build
rm -rf "$B"; mkdir -p "$B/assets" "$B/classes" "$OUT"
cp "$HTML" "$B/assets/index.html"

# Imza anahtari (yoksa olusturulur). Bu dosyayi GitHub'a KOYMA.
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -keystore "$KEYSTORE" -storepass "$KS_PASS" -keypass "$KS_PASS" -alias sanal \
    -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Sanal Makine, O=Emir, C=TR"
fi

# 1) Kaynaklar
"$AAPT2" compile --dir res -o "$B/res.zip"
LINK="--manifest AndroidManifest.xml -I $ANDROID_JAR --min-sdk-version 21 --target-sdk-version 34 \
      --version-code $VERSION_CODE --version-name $VERSION_NAME -A $B/assets --auto-add-overlay"
"$AAPT2" link $LINK -o "$B/base.apk" "$B/res.zip"
"$AAPT2" link $LINK --proto-format -o "$B/proto.apk" "$B/res.zip"

# 2) Java -> dex
javac -source 8 -target 8 -encoding UTF-8 -nowarn -Xlint:-options -bootclasspath "$ANDROID_JAR" \
      -d "$B/classes" src/com/emir/sanalmakine/*.java
dalvik-exchange --dex --min-sdk-version=21 --output="$B/classes.dex" "$B/classes"

# 3) APK: dex ekle, hizala, imzala
cp "$B/base.apk" "$B/unsigned.apk"
(cd "$B" && zip -q -j unsigned.apk classes.dex)
zipalign -p -f 4 "$B/unsigned.apk" "$B/aligned.apk"
apksigner sign --v4-signing-enabled false --ks "$KEYSTORE" --ks-pass "pass:$KS_PASS" --ks-key-alias sanal \
  --out "$OUT/SanalMakine.apk" "$B/aligned.apk"
apksigner verify "$OUT/SanalMakine.apk"

# 4) AAB (Google Play icin)
M="$B/module"; mkdir -p "$M/manifest" "$M/dex"
(cd "$M" && unzip -q ../proto.apk)
mv "$M/AndroidManifest.xml" "$M/manifest/AndroidManifest.xml"
cp "$B/classes.dex" "$M/dex/classes.dex"
(cd "$M" && zip -q -r ../base-module.zip .)
rm -f "$OUT/SanalMakine.aab"
java -jar "$BUNDLETOOL" build-bundle --modules="$B/base-module.zip" --output="$OUT/SanalMakine.aab"
jarsigner -keystore "$KEYSTORE" -storepass "$KS_PASS" -sigalg SHA256withRSA -digestalg SHA-256 \
  "$OUT/SanalMakine.aab" sanal >/dev/null
ls -la "$OUT"
